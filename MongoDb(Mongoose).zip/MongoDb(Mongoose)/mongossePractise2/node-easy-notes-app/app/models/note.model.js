const mongoose = require('mongoose');

const PlayerSchema = mongoose.Schema({
    title: String,
    content: String
},{
    timestamps: true,
    versionKey: false // You should be aware of the outcome after set to false
});

module.exports = mongoose.model('Note', PlayerSchema);
